#!/bin/sh

export GO111MODULE=on
export GOFLAGS=-mod=vendor

go test -v ./pkg/integration_test

