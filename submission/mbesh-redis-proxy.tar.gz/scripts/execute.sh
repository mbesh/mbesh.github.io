#!/bin/bash

# Build the services
docker-compose -f docker-compose.test.yml build

# Start the backing services as daemons
docker-compose -f docker-compose.test.yml up -d redis redis-proxy

# Start the tester
HAS_ERRORS=0
docker-compose -f docker-compose.test.yml up tester
if [ $? -ne 0 ]; then
  HAS_ERRORS=1
fi

# Shutdown the services
docker-compose -f docker-compose.test.yml down

# Return the exit code corresponding to the success of the tests
if [[ $HAS_ERRORS -ne 0 ]]; then exit 1;  fi