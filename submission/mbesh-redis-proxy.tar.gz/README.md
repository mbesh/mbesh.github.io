# redis-proxy
A transparent proxy service for retrieving values from Redis.

## Architecture overview
`redis-proxy` acts as an HTTP proxy in front of a configured backing Redis instance. `redis-proxy` has a simple HTTP GET handler configured on its root path wherein any value is considered the `key` in a Redis lookup. For example, the following will look up the key `somekey`:
```
curl http://redis-proxy/somekey
```

Each instance will retrieve values from its backing Redis instance and cache values in its own least-recently-used (LRU) cache. The LRU cache is configured with a maximum capacity and time-to-live duration. `redis-proxy` will attempt to purge stale items approximately four times over the period of the configured duration to reduce stale items remaining longer than expected.

## What the code does

### Web server
Found in the [server package](pkg/server), the `NewServer` function will instantiate a `redis-proxy` web server with the passed configuration. Calling the `Start()` method on this server will start the server's web listener and begin handling traffic as well as spawn a goroutine to periodically purge the LRU cache. It uses [julienschmidt/httprouter](https://github.com/julienschmidt/httprouter) to handle routing of requests to request handlers.

### Request handlers
In the [handlers package](pkg/handlers), the `RegisterHandlers` function configures all request handlers onto the passed `httprouter.Router`. The [RedisHandler](pkg/handlers/redis.go) handles the GET requests to Redis.

### Redis Integration
The [redis package](pkg/redis) contains the client code that interacts with Redis and stores values in the LRU cache.

### LRU cache
The LRU cache is implemented through the use of a doubly-linked list provided by the `container/list` package in Go and found in the [lrucache package](pkg/lrucache). When an item is retrieved or added, it is placed at the front of the list. If the capacity of the LRU cache is exceeded during an add, the last item item in the list is removed. The LRU cache maintains a map of list elements keyed on the string `key` to aid in the look up of values. Each value within the list stores its most recently accessed date to support purging stale items.

The LRU cache has a `sync.RWMutex` which is acquired and released udring each operation on the cache (add, get, purge) to enable safe concurrent operations.

### Configuration
The [config package](pkg/config) uses the [envconfig](https://github.com/kelseyhightower/envconfig) package to retrieve environment variables and store them within a struct.

### Scripts
The [scripts directory](scripts) contains shell scripts used for the execution of tests.

### Dockerfiles
The [dockerfiles directory](dockerfiles) contains Dockerfiles used for building Docker containers.

## Algorithmic complexity of cache operations
* Get - O(1)
* Add (includes eviction) - O(1)
* Purging expired items - O(N)

## How to run the proxy and tests
Run `make test` to start the proxy and tests. If you want to see the logging output of the proxy server and execute tests, run `docker-compose -f docker-compose.test.yml up`

## How long spent on each part of the project
| Part | Time Estimate (approx.) |
|---|---|
| Web server  | 2 hours
| LRU cache | 2 hours |
| Docker wizardry | 2 hours |
| Integration tests | 1 hour |
| Documentation | 2 hours |

## Unimplemented requirements
* Concurrent processing (configurable maximum limit) -- time
