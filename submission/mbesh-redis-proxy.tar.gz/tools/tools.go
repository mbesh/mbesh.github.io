// +build tools

// package tools exists to force Go Modules to depend on these packages as
// though we were using them as libraries.
//
package tools

import (
	_ "golang.org/x/lint/golint"
)
