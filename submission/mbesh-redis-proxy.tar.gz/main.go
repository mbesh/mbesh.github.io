package main

import (
	"github.com/sirupsen/logrus"

	"github.com/mbesh/redis-proxy/pkg/config"
	"github.com/mbesh/redis-proxy/pkg/log"
	"github.com/mbesh/redis-proxy/pkg/server"
)

func main() {
	log.InitLogger()
	srvConf := config.ParseConfig()
	s, err := server.NewServer(srvConf)
	if err != nil {
		logrus.Fatalf("An unexpected error occurred while creating the server: %+v", err)
	}

	s.Start()
}
