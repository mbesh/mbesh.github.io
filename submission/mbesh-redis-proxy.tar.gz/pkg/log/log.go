package log

import (
	"os"

	"github.com/kelseyhightower/envconfig"
	"github.com/sirupsen/logrus"
)

const (
	// defaultLevel is the default logging level used
	defaultLevel = logrus.InfoLevel
)

type config struct {
	Level string `envconfig:"LOG_LEVEL" default:"INFO"`
}

// InitLogger initializes the logger settings based upon environment
// configuration.
func InitLogger() {
	cfg := config{}
	envconfig.MustProcess("", &cfg)
	level, err := logrus.ParseLevel(cfg.Level)
	if err != nil {
		logrus.WithError(err).Warnf("Unable to parse log level (%s) using the default (%s)", cfg.Level, defaultLevel)
		level = defaultLevel
	}
	logrus.SetLevel(level)
	logrus.SetOutput(os.Stderr)
	logrus.SetFormatter(&logrus.TextFormatter{
		ForceColors: true,
	})
}
