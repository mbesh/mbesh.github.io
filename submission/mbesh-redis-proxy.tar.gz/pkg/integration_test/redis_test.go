package integration_test

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mbesh/redis-proxy/pkg/handlers"
)

func NewHTTPClient() *http.Client {
	return &http.Client{
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

type keyValuePair struct {
	key, value string
}

func TestRedisIntegration(t *testing.T) {

	fmt.Println("TestRedisIntegration...")
	redisClient, err := InitRedisClient()
	require.NoError(t, err)

	redisProxyRootURL := fmt.Sprintf("http://%v:%v/", config.ProxyHost, config.ProxyPort)
	t.Run("no value in cache", func(st *testing.T) {
		key := "somekey"
		expectedOut := &handlers.RedisResponse{}
		GetWithExpectedResponse(st, redisProxyRootURL, key, http.StatusOK, expectedOut)
	})

	t.Run("value in cache", func(st *testing.T) {
		key := "valueInCacheTest1Key"
		value := "somevalue"
		redisClient.Set(key, value, 0)
		defer redisClient.Del(key)

		expectedOut := &handlers.RedisResponse{
			Value:  value,
			Cached: false,
		}
		GetWithExpectedResponse(st, redisProxyRootURL, key, http.StatusOK, expectedOut)
	})

	t.Run("over capacity", func(st *testing.T) {
		kvs := []keyValuePair{
			keyValuePair{"overCapacityKey1", "value1"},
			keyValuePair{"overCapacityKey2", "value2"},
			keyValuePair{"overCapacityKey3", "value3"},
			keyValuePair{"overCapacityKey4", "value4"},
			keyValuePair{"overCapacityKey5", "value5"},
			keyValuePair{"overCapacityKey6", "value6"},
		}
		keys := []string{}
		// Put Key-Values in the Redis cache
		for i := range kvs {
			redisClient.Set(kvs[i].key, kvs[i].value, 0)
			keys = append(keys, kvs[i].key)
		}
		defer redisClient.Del(keys...)

		// Retrieve each key to make the proxy cache go over capacity
		for i := range kvs {
			expectedOut := &handlers.RedisResponse{
				Cached: false,
				Value:  kvs[i].value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, kvs[i].key, http.StatusOK, expectedOut)
		}

		// Expect that key 6 will be present in the cache
		{
			expectedOut := &handlers.RedisResponse{
				Cached: true,
				Value:  kvs[5].value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, kvs[5].key, http.StatusOK, expectedOut)
		}
		// Expect that key 1 will not be present in the cache
		{
			expectedOut := &handlers.RedisResponse{
				Cached: false,
				Value:  kvs[0].value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, kvs[0].key, http.StatusOK, expectedOut)
		}
	})

	t.Run("cache purge", func(st *testing.T) {
		// Put Key-Values in the Redis cache
		key := "purgeKey1"
		value := "value"
		redisClient.Set(key, value, 0)

		defer redisClient.Del(key)

		// Retrieve the key to make the proxy cache the value
		{
			expectedOut := &handlers.RedisResponse{
				Cached: false,
				Value:  value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, key, http.StatusOK, expectedOut)
		}

		// Expect that the key will be present in the cache
		{
			expectedOut := &handlers.RedisResponse{
				Cached: true,
				Value:  value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, key, http.StatusOK, expectedOut)
		}

		// Wait 7 seconds (5s is the configured purge time)
		fmt.Println("waiting 7s for cache to purge")
		time.Sleep(7 * time.Second)

		// Expect that key will not be present in the cache
		{
			expectedOut := &handlers.RedisResponse{
				Cached: false,
				Value:  value,
			}
			GetWithExpectedResponse(st, redisProxyRootURL, key, http.StatusOK, expectedOut)
		}
	})
}

func GetWithExpectedResponse(t *testing.T, url, key string, expectedStatusCode int, expectedResponse *handlers.RedisResponse) {
	client := NewHTTPClient()
	req, _ := http.NewRequest("GET", fmt.Sprintf("%v%v", url, key), nil)
	resp, err := client.Do(req)
	require.NoError(t, err)
	b, _ := ioutil.ReadAll(resp.Body)
	assert.Equal(t, expectedStatusCode, resp.StatusCode)

	response := &handlers.RedisResponse{}
	err = json.Unmarshal(b, response)
	require.NoError(t, err)
	assert.Equal(t, expectedResponse, response)
}
