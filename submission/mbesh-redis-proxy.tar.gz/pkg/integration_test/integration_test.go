package integration_test

import (
	"fmt"
	"os"
	"testing"

	"github.com/go-redis/redis"

	"github.com/kelseyhightower/envconfig"
	"github.com/sirupsen/logrus"
)

type testConfig struct {
	RedisHost string `envconfig:"redis_host" default:"redis"`
	RedisPort int    `envconfig:"redis_port" default:"6379"`
	ProxyHost string `envconfig:"proxy_host" default:"redis-proxy"`
	ProxyPort int    `envconfig:"proxy_port" default:"8080"`
}

var config *testConfig

func TestMain(m *testing.M) {
	fmt.Println("Configuring integration tests...")
	if os.Getenv("RUN_INTEGRATION_TESTS") == "true" {
		fmt.Println("Running integration tests...")
		conf := testConfig{}
		err := envconfig.Process("", &conf)
		if err != nil {
			logrus.Fatalf("Failed to parse server config: %s", err.Error())
		}
		config = &conf
		os.Exit(m.Run())
	}
}

func InitRedisClient() (*redis.Client, error) {
	redisClient := redis.NewClient(&redis.Options{
		Addr: fmt.Sprintf("%v:%v", config.RedisHost, config.RedisPort),
	})
	if _, err := redisClient.Ping().Result(); err != nil {
		logrus.WithError(err).Error("redis: unable to connect")
		return nil, err
	}
	return redisClient, nil
}
