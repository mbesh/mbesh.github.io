package version

// Version of our codebase, automatically injected via build scripts.
var Version string
