package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/julienschmidt/httprouter"
	"github.com/sirupsen/logrus"

	"github.com/mbesh/redis-proxy/pkg/redis"
)

// RedisHandler is a request handler for retrieving values from Redis.
type RedisHandler struct {
	redisClient *redis.Client
}

// Handle validates input and attempts to load a key from the redis cache.
func (rh *RedisHandler) Handle(w http.ResponseWriter, r *http.Request, p httprouter.Params) {
	key := p.ByName("key")
	if key == "" {
		WriteError(w, http.StatusBadRequest, fmt.Errorf("No key provided"))
		return
	}
	logrus.WithField("key", key).Info("Looking up key")
	value, cached := rh.redisClient.Get(key)
	logrus.WithFields(logrus.Fields{
		"key":       key,
		"value":     value,
		"wasCached": cached,
	}).Info("Got value for key")

	w.WriteHeader(http.StatusOK)
	resp := &RedisResponse{
		Value:  value,
		Cached: cached,
	}
	b, _ := json.Marshal(resp)
	w.Header().Set("Content-Type", "application/json")
	_, err := w.Write(b)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, err)
	}
}

// RedisResponse represents the JSON body returned when interacting with
// the API.
type RedisResponse struct {
	Value  string `json:"value"`
	Cached bool   `json:"cached"`
}
