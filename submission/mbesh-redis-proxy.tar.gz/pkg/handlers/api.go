package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/julienschmidt/httprouter"
	"github.com/sirupsen/logrus"

	"github.com/mbesh/redis-proxy/pkg/redis"
)

const (
	defaultErrorJSON = `{"status": 500, "error": {"message": "Internal server error"}}`
)

// RegisterHandlers registers API handlers to endpoints.
func RegisterHandlers(r *httprouter.Router, redisClient *redis.Client) {
	r.NotFound = http.HandlerFunc(NotFound)
	r.MethodNotAllowed = http.HandlerFunc(MethodNotAllowed)
	r.PanicHandler = PanicHandler

	proxyHandler := &RedisHandler{redisClient: redisClient}
	r.GET("/:key", proxyHandler.Handle)
}

// NotFound is the default handler for undefined routes.
func NotFound(w http.ResponseWriter, r *http.Request) {
	err := fmt.Errorf("%v is not a valid path", r.URL.Path)
	logrus.WithError(err).Warn("invalid request — returned 404")
	WriteError(w, http.StatusNotFound, err)
}

// MethodNotAllowed is the default handler for undefined methods.
func MethodNotAllowed(w http.ResponseWriter, r *http.Request) {
	err := fmt.Errorf("%v method is not valid for path %v", r.Method, r.URL.Path)
	logrus.WithError(err).Warn("invalid method — returning 503")
	WriteError(w, http.StatusMethodNotAllowed, err)
}

// PanicHandler creates the default handler for catching requests that cause
// a panic.
func PanicHandler(w http.ResponseWriter, r *http.Request, panicError interface{}) {
	err := fmt.Errorf("panic occurred! %+v", panicError)
	logrus.WithError(err).Warnf("a panic occurred on the server!")
	WriteError(w, http.StatusInternalServerError, err)
}

// WriteError constructs an error response and writes it to the http.ResponseWriter
func WriteError(w http.ResponseWriter, status int, err error) {
	resp := ErrorResponse{
		Status: status,
		Error:  &ErrorValues{Message: err.Error()},
	}

	b, err := json.Marshal(resp)
	if err != nil {
		http.Error(w, defaultErrorJSON, http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(resp.Status)
	_, err = w.Write(b)
	if err != nil {
		http.Error(w, defaultErrorJSON, http.StatusInternalServerError)
		return
	}
}

// ErrorResponse defines the structure for an error API response.
type ErrorResponse struct {
	Status int          `json:"status,omitempty"`
	Error  *ErrorValues `json:"error,omitempty"`
}

// ErrorValues defines the fields returned on a response with an error.
type ErrorValues struct {
	Message string `json:"message,omitempty"`
	// Fields indicates which fields of the request json body are wrong.
	// It is only intended to be used in a HTTP POST context.
	Fields []string `json:"fields,omitempty"`
}
