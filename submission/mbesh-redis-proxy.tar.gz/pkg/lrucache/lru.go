package lrucache

import (
	"container/list"
	"errors"
	"sync"
	"time"
)

// LRUCache is a thread-safe implementation of a LRU cache. It uses a doubly-
// linked list backing store as implemented by List in the container/list
// package.
type LRUCache struct {
	lock sync.RWMutex
	list *list.List

	elementMap map[string]*list.Element

	// now func to support dependency injection for unit testing.
	now func() time.Time

	maxSize int
}

// cachedValue stores a cached value and its last access time
type cachedValue struct {
	key            string
	value          interface{}
	lastAccessDate time.Time
}

// NewLRUCache instantiates a LRU cache with the specified size. If maximumSize
// is less than 1, this will return an error.
func NewLRUCache(maximumSize int) (*LRUCache, error) {
	if maximumSize <= 0 {
		return nil, errors.New("Maximum size of a LRU cache must be >= 1")
	}
	cache := &LRUCache{
		maxSize:    maximumSize,
		list:       list.New(),
		elementMap: map[string]*list.Element{},
		now:        time.Now,
	}
	return cache, nil
}

// Add a value to the cache.
func (lruCache *LRUCache) Add(key string, value interface{}) {
	// Acquire lock and release when Add completes
	lruCache.lock.Lock()
	defer lruCache.lock.Unlock()

	// If an element already exists in the list, we will move it to the front
	// and update it to store the most current time.
	if existingElement, ok := lruCache.elementMap[key]; ok {
		lruCache.list.MoveToFront(existingElement)
		storedCacheObject := existingElement.Value.(*cachedValue)
		// update the stored value
		storedCacheObject.value = value
		// update the access date
		storedCacheObject.lastAccessDate = lruCache.now()
		return
	}

	// If no element existed, create a new cached value one and update the map
	newCachedValue := &cachedValue{
		key:            key,
		value:          value,
		lastAccessDate: lruCache.now(),
	}
	// Add to the front of the list and get a list.Element
	newElement := lruCache.list.PushFront(newCachedValue)
	// Update the element map
	lruCache.elementMap[key] = newElement

	// Drop the last value if we are exceeding size
	if lruCache.list.Len() > lruCache.maxSize {
		lruCache.removeLast()
	}
}

// Get returns the value stored with the passed key in the LRU cache and a
// boolean to represent whether the key was found (to support nil values). If
// found, the associated element will be made the most recently used element
// in the cache and have its access date updated.
func (lruCache *LRUCache) Get(key string) (interface{}, bool) {
	// Acquire lock and release when Get completes to guard against removal
	lruCache.lock.Lock()
	defer lruCache.lock.Unlock()
	if existingElement, ok := lruCache.elementMap[key]; ok {
		lruCache.list.MoveToFront(existingElement)
		storedCacheObject := existingElement.Value.(*cachedValue)
		// Update the access date
		storedCacheObject.lastAccessDate = lruCache.now()
		return storedCacheObject.value, true
	}
	return nil, false
}

// removeLast is NOT thread-safe and is expected to be used within thread-safe
// methods. Removes the last element on the LRU cache.
func (lruCache *LRUCache) removeLast() {
	lastElement := lruCache.list.Back()
	// In case this was called with an empty list, we'll return gracefully
	if lastElement == nil {
		return
	}
	storedCacheObject := lastElement.Value.(*cachedValue)
	// Remove the cached object from the element map
	delete(lruCache.elementMap, storedCacheObject.key)

	// Remove the element from the list
	lruCache.list.Remove(lastElement)
}

// PurgeValuesOlderThan will purge values that haven't been accessed since
// Now - duration.
func (lruCache *LRUCache) PurgeValuesOlderThan(duration time.Duration) int {
	lruCache.lock.Lock()
	defer lruCache.lock.Unlock()
	elementsMustBeAfter := lruCache.now().Add(-1 * duration)
	elem := lruCache.list.Front()
	requiresDelete := false

	for elem != nil {
		storedCacheObject := elem.Value.(*cachedValue)
		if storedCacheObject.lastAccessDate.Before(elementsMustBeAfter) {
			requiresDelete = true
			break
		}
		elem = elem.Next()
	}

	removeCount := 0
	if requiresDelete {
		// Purge all elements after the currently found old value
		for elem != nil {
			// Get the next element to remove before we clear the pointers
			next := elem.Next()
			removeCount++

			storedCacheObject := elem.Value.(*cachedValue)
			// Remove the cached object from the element map
			delete(lruCache.elementMap, storedCacheObject.key)
			// Remove the element from the list
			lruCache.list.Remove(elem)
			// Continue the purge on the next element
			elem = next
		}
	}
	return removeCount
}
