package lrucache

import (
	"container/list"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestPurgeOlderThan(t *testing.T) {
	t.Parallel()

	t.Run("with three values purgeable", func(st *testing.T) {
		testCache := &LRUCache{
			maxSize:    10,
			list:       list.New(),
			elementMap: map[string]*list.Element{},
			now: func() time.Time {
				return time.Now().Add(-10 * time.Minute)
			},
		}
		testCache.Add("a", 1)
		testCache.Add("b", 2)
		testCache.Add("c", 3)

		testCache.now = time.Now
		testCache.Add("d", 4)

		// Remove all things not accessed within one minute
		out := testCache.PurgeValuesOlderThan(1 * time.Minute)
		assert.Equal(st, 3, out)

		// Verify key "d" still exists
		value, ok := testCache.Get("d")
		assert.True(st, ok)
		assert.Equal(st, 4, value)

		// Verify key "a" doesn't exist
		_, ok = testCache.Get("a")
		assert.False(st, ok)
	})

	t.Run("with no values", func(st *testing.T) {
		testCache := &LRUCache{
			maxSize:    10,
			list:       list.New(),
			elementMap: map[string]*list.Element{},
			now:        time.Now,
		}
		out := testCache.PurgeValuesOlderThan(1 * time.Minute)
		assert.Equal(st, 0, out)
	})
}

func TestAdd(t *testing.T) {
	t.Parallel()

	t.Run("basic add", func(st *testing.T) {
		testCache, err := NewLRUCache(4)
		require.NoError(st, err)
		in := "some value"
		testCache.Add("x", in)
		out, _ := testCache.Get("x")
		assert.Equal(st, in, out)
	})

	t.Run("invalid size", func(st *testing.T) {
		_, err := NewLRUCache(-1)
		assert.Error(st, err)
	})

	t.Run("over capacity", func(st *testing.T) {
		testCache, err := NewLRUCache(1)
		require.NoError(st, err)
		in := "some value"
		testCache.Add("x", in)
		out, _ := testCache.Get("x")
		assert.Equal(st, in, out)

		in2 := "another value"
		testCache.Add("y", in2)
		out, _ = testCache.Get("y")
		assert.Equal(st, in2, out)

		out, ok := testCache.Get("x")
		assert.Nil(st, out)
		assert.False(st, ok)
	})

}
