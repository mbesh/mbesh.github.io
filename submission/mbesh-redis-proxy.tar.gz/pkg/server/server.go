package server

import (
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/julienschmidt/httprouter"
	"github.com/rs/cors"
	"github.com/sirupsen/logrus"

	"github.com/mbesh/redis-proxy/pkg/config"
	"github.com/mbesh/redis-proxy/pkg/handlers"
	"github.com/mbesh/redis-proxy/pkg/lrucache"
	"github.com/mbesh/redis-proxy/pkg/redis"
	"github.com/mbesh/redis-proxy/pkg/version"
)

// Server represents a redis-proxy server capable of handling HTTP requests.
type Server struct {
	config     *config.Config
	shutdownCh chan os.Signal

	listener net.Listener
	router   *httprouter.Router

	lruCache *lrucache.LRUCache
}

// NewServer will initialize a server with the specified configuration.
func NewServer(config *config.Config) (*Server, error) {
	s := &Server{
		config:     config,
		shutdownCh: make(chan os.Signal, 1),
		router:     httprouter.New(),
	}

	// Set up the server on the specified address and port
	l, err := net.Listen(config.TCPAddr.Network(), config.TCPAddr.String())
	if err != nil {
		return nil, fmt.Errorf("Server failed to listen on %s: %s", config.TCPAddr.String(), err.Error())
	}
	s.listener = l

	// Create the LRU cache
	lruCache, err := lrucache.NewLRUCache(config.CacheMaximumSize)
	if err != nil {
		return nil, err
	}
	s.lruCache = lruCache

	// Create redis client
	redisClient, err := redis.NewClient(config.RedisHost, config.RedisPort, lruCache)
	if err != nil {
		return nil, err
	}

	// Register handlers on the router
	handlers.RegisterHandlers(s.router, redisClient)

	return s, nil
}

// Start starts the server.
func (s *Server) Start() {
	// Want two signals: one for cache expiration goroutine and another
	// for the main server
	signal.Notify(s.shutdownCh, os.Interrupt, syscall.SIGTERM)
	signal.Notify(s.shutdownCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-s.shutdownCh
		s.Shutdown()
	}()

	// Start a listener that purges the cache based on the configured time.
	go func() {
		for {
			select {
			case <-s.shutdownCh:
				logrus.Info("Shutting down cache expiration goroutine")
				return
			default:
				time.Sleep(s.config.CacheExpiryDuration / 4)
				purged := s.lruCache.PurgeValuesOlderThan(s.config.CacheExpiryDuration)
				if purged > 0 {
					logrus.WithFields(logrus.Fields{
						"purgedKeys": purged,
						"duration":   s.config.CacheExpiryDuration,
					}).Infof("Purged LRU cache of stale values")
				}
			}
		}
	}()

	logrus.Fatal(s.ListenAndServe())
}

// Shutdown handles cleaning up the listener when the server is shutdown.
func (s *Server) Shutdown() {
	logrus.Info("Shutting down server...")
	if err := s.listener.Close(); err != nil {
		logrus.WithError(err).Error("server: failed to close server properly")
	}
}

// ListenAndServe starts the Server and will block until the server is
// shutdown.
func (s *Server) ListenAndServe() error {
	logrus.Infof("Starting redis proxy server [version: %v] on %s", version.Version, s.listener.Addr().String())

	// Note: need a properly configured CORS handler for production API use
	corsHandler := cors.AllowAll()
	err := http.Serve(s.listener, corsHandler.Handler(s.router))
	return err
}
