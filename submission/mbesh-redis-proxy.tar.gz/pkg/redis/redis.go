package redis

import (
	"fmt"

	"github.com/go-redis/redis"
	"github.com/mbesh/redis-proxy/pkg/lrucache"
	"github.com/sirupsen/logrus"
)

// Client will handle all Redis interactions
type Client struct {
	redisClient *redis.Client
	lruCache    *lrucache.LRUCache
}

// NewClient creates a proxied redis client.
func NewClient(host string, port int, lruCache *lrucache.LRUCache) (*Client, error) {
	redisClient := redis.NewClient(&redis.Options{
		Addr: fmt.Sprintf("%v:%v", host, port),
	})
	if _, err := redisClient.Ping().Result(); err != nil {
		logrus.WithError(err).Error("redis: unable to connect")
		return nil, err
	}
	return &Client{
		redisClient: redisClient,
		lruCache:    lruCache,
	}, nil
}

// Get will retrieve a key from Redis.
func (c *Client) Get(key string) (string, bool) {
	if cachedValue, ok := c.lruCache.Get(key); ok {
		return cachedValue.(string), true
	}

	result, err := c.redisClient.Get(key).Result()
	if err != nil {
		logrus.WithError(err).Warn("redis miss: ", key)
		return "", false
	}

	c.lruCache.Add(key, result)
	return result, false
}
