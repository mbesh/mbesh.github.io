package config

import (
	"fmt"
	"net"
	"time"

	"github.com/kelseyhightower/envconfig"
	"github.com/sirupsen/logrus"
)

// Config stores the configuration for the server.
type Config struct {
	Host    string `envconfig:"tcp_bind_addr" default:"0.0.0.0"`
	Port    int    `envconfig:"tcp_bind_port" default:"8080"`
	TCPAddr *net.TCPAddr

	RedisHost string `envconfig:"redis_host" default:"redis"`
	RedisPort int    `envconfig:"redis_port" default:"6379"`

	CacheMaximumSize                int    `envconfig:"cache_maximum_size" default:"10"`
	CacheExpiryDurationFormatString string `envconfig:"cache_expiration_duration" default:"1m"`
	CacheExpiryDuration             time.Duration
}

// Parses a TCP address and returns a net.TCPAddr
func parseAddr(ip string, port int) (*net.TCPAddr, error) {
	ipAddr := net.ParseIP(ip)
	if ipAddr == nil {
		return nil, fmt.Errorf("Failed to parse IP from string: %s", ip)
	}
	return &net.TCPAddr{IP: ipAddr, Port: port}, nil
}

// ParseConfig will read the currently set environment variables and return
// the server configuration.
func ParseConfig() *Config {
	var conf Config
	err := envconfig.Process("", &conf)
	if err != nil {
		logrus.Fatalf("Failed to parse server config: %s", err.Error())
	}
	// Parse TCP Addr
	tcpAddr, err := parseAddr(conf.Host, conf.Port)
	if err != nil {
		logrus.Fatalf("Error parsing TCP address: %+v", err.Error())
	}
	conf.TCPAddr = tcpAddr

	duration, err := time.ParseDuration(conf.CacheExpiryDurationFormatString)
	if err != nil {
		logrus.Warnf("Invalid duration format string '%v' provided, using default of 1 minute", conf.CacheExpiryDurationFormatString)
		duration = 1 * time.Minute
	}
	conf.CacheExpiryDuration = duration

	return &conf
}
